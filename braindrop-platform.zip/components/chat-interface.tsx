"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Send, Mic, Copy, Brain, User, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
  subject?: string
}

interface ChatInterfaceProps {
  selectedSubject: string
  onSubjectChange: (subject: string) => void
}

const subjects = [
  { value: "physics", label: "Physics", labelBn: "পদার্থবিজ্ঞান" },
  { value: "chemistry", label: "Chemistry", labelBn: "রসায়ন" },
  { value: "biology", label: "Biology", labelBn: "জীববিজ্ঞান" },
  { value: "mathematics", label: "Mathematics", labelBn: "গণিত" },
  { value: "general", label: "General Science", labelBn: "সাধারণ বিজ্ঞান" },
]

const quickQuestions = {
  physics: [
    "What is Newton's first law?",
    "Explain electromagnetic induction",
    "How does a transformer work?",
    "What is the photoelectric effect?",
  ],
  chemistry: [
    "What is the periodic table?",
    "Explain chemical bonding",
    "What are acids and bases?",
    "How does photosynthesis work?",
  ],
  biology: [
    "What is cell division?",
    "Explain the circulatory system",
    "How does digestion work?",
    "What is photosynthesis?",
  ],
  mathematics: [
    "Solve quadratic equations",
    "What is trigonometry?",
    "Explain coordinate geometry",
    "How to find derivatives?",
  ],
  general: [
    "What is the scientific method?",
    "Explain the water cycle",
    "What causes seasons?",
    "How do magnets work?",
  ],
}

export function ChatInterface({ selectedSubject, onSubjectChange }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Add welcome message when component mounts or subject changes
    if (selectedSubject) {
      const subject = subjects.find((s) => s.value === selectedSubject)
      const welcomeMessage: Message = {
        id: `welcome-${Date.now()}`,
        content: `Hello! I'm your AI study companion for ${subject?.label} (${subject?.labelBn}). I'm here to help you with your Class 9-10 studies. Ask me anything about concepts, problems, or explanations!

আপনাকে স্বাগতম! আমি ${subject?.labelBn} (${subject?.label}) এর জন্য আপনার AI পড়াশোনার সাথী। আমি আপনার ক্লাস ৯-১০ এর পড়াশোনায় সাহায্য করতে এখানে আছি। ধারণা, সমস্যা বা ব্যাখ্যা সম্পর্কে যেকোনো প্রশ্ন করুন!`,
        sender: "ai",
        timestamp: new Date(),
        subject: selectedSubject,
      }
      setMessages([welcomeMessage])
    }
  }, [selectedSubject])

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      content: inputValue,
      sender: "user",
      timestamp: new Date(),
      subject: selectedSubject,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        content: `Great question about ${selectedSubject}! Let me help you understand this concept.

This is a simulated response. In a real implementation, this would connect to an AI service to provide detailed explanations, step-by-step solutions, and educational content tailored to Class 9-10 students in Bangladesh.

The response would include:
- Clear explanations in both English and Bengali
- Step-by-step problem solving
- Related concepts and examples
- Practice questions for better understanding

আপনার প্রশ্নের জন্য ধন্যবাদ! এটি একটি নমুনা উত্তর। প্রকৃত বাস্তবায়নে, এটি AI সেবার সাথে সংযুক্ত হয়ে বিস্তারিত ব্যাখ্যা, ধাপে ধাপে সমাধান এবং বাংলাদেশের ক্লাস ৯-১০ শিক্ষার্থীদের জন্য উপযুক্ত শিক্ষামূলক বিষয়বস্তু প্রদান করবে।`,
        sender: "ai",
        timestamp: new Date(),
        subject: selectedSubject,
      }
      setMessages((prev) => [...prev, aiMessage])
      setIsLoading(false)
    }, 1500)
  }

  const handleQuickQuestion = (question: string) => {
    setInputValue(question)
    inputRef.current?.focus()
  }

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const currentQuestions = selectedSubject ? quickQuestions[selectedSubject as keyof typeof quickQuestions] || [] : []

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sidebar */}
      <div className="hidden lg:flex w-80 border-r border-border bg-muted/30 flex-col">
        <div className="p-4 border-b border-border">
          <h3 className="font-semibold mb-3">Subject</h3>
          <Select value={selectedSubject} onValueChange={onSubjectChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select Subject" />
            </SelectTrigger>
            <SelectContent>
              {subjects.map((subject) => (
                <SelectItem key={subject.value} value={subject.value}>
                  <div className="flex flex-col">
                    <span>{subject.label}</span>
                    <span className="text-xs text-muted-foreground">{subject.labelBn}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedSubject && (
          <div className="p-4 flex-1">
            <h3 className="font-semibold mb-3">Quick Questions</h3>
            <div className="space-y-2">
              {currentQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-start text-left h-auto p-3 text-sm"
                  onClick={() => handleQuickQuestion(question)}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex items-center justify-center h-full">
              <Card className="max-w-md">
                <CardContent className="p-6 text-center">
                  <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Start a Conversation</h3>
                  <p className="text-sm text-muted-foreground">Ask me anything about your studies. I'm here to help!</p>
                </CardContent>
              </Card>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={cn("flex gap-3", message.sender === "user" ? "justify-end" : "justify-start")}
            >
              {message.sender === "ai" && (
                <Avatar className="h-8 w-8 mt-1">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <Brain className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}

              <div
                className={cn(
                  "max-w-[80%] rounded-lg p-4 relative group",
                  message.sender === "user"
                    ? "bg-primary text-primary-foreground ml-12"
                    : "bg-card border border-border",
                )}
              >
                <div className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</div>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-border/50">
                  <span className="text-xs opacity-70">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                  {message.sender === "ai" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0"
                      onClick={() => copyMessage(message.content)}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>

              {message.sender === "user" && (
                <Avatar className="h-8 w-8 mt-1">
                  <AvatarFallback className="bg-secondary text-secondary-foreground">
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <Avatar className="h-8 w-8 mt-1">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <Brain className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">Thinking...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-border p-4">
          {selectedSubject && (
            <div className="mb-3">
              <Badge variant="secondary" className="text-xs">
                {subjects.find((s) => s.value === selectedSubject)?.label} -{" "}
                {subjects.find((s) => s.value === selectedSubject)?.labelBn}
              </Badge>
            </div>
          )}

          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Input
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask me anything about your studies... / আপনার পড়াশোনা সম্পর্কে যেকোনো প্রশ্ন করুন..."
                className="pr-12"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSendMessage()
                  }
                }}
              />
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                disabled
              >
                <Mic className="h-4 w-4" />
              </Button>
            </div>
            <Button onClick={handleSendMessage} disabled={!inputValue.trim() || isLoading} className="px-4">
              <Send className="h-4 w-4" />
            </Button>
          </div>

          <p className="text-xs text-muted-foreground mt-2 text-center">
            Press Enter to send • Shift + Enter for new line
          </p>
        </div>
      </div>
    </div>
  )
}
